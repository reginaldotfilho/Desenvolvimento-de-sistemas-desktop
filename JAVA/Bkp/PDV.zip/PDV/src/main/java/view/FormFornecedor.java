package view;

import javax.swing.*;

public class FormFornecedor extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;

    public FormFornecedor() {
        setTitle("Fornecedor");
        setSize(1000,600);
        setLocationRelativeTo(null);
        setContentPane(contentPane);
        setModal(true);

    }
}
