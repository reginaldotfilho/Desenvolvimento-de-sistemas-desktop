package view;

import connection.ConnectionFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class FormPrincipal extends JFrame {
    private JPanel pnlMain;
    private JButton fornecedoresButton;
    private JButton produtosButton;
    private JButton PDVButton;
    private JButton vendasButton;
    private JButton sairButton;
    private JPanel pnlFooter;
    private JPanel pnlButton;
    private JPanel pnlDash;
    private JPanel pnlGrafico;
    private JLabel lblData;
    private JLabel lblDatabase;
    private JLabel lblBanco;
    private JLabel lblSobre;
    private JLabel lblConexao;

    public FormPrincipal() {

        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("RTech");
        setLocationRelativeTo(null);
        setContentPane(pnlMain);
        setResizable(false);

        atualizarData();
        verificarConexao();

//botôes=====================================================================
        lblSobre.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        lblSobre.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
               // IO.println("Teste do Sobre");
                sobre();
            }
        });

        fornecedoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FormFornecedor formFornecedor = new FormFornecedor();
                formFornecedor.setVisible(true);
            }
        });
    }//fim construtor

    //testar a conexão com o banco de dados
    //criando um metodo verificarConexao
    private void verificarConexao() {
        //criar o objeto para acessar o metodo testaConexao()
        ConnectionFactory conexao = new ConnectionFactory();
        //se retorno for  verdadeiro concexão bem sucedida
        if (conexao.testarConexao() == true ) {
            lblBanco.setText("Banco Conectado");
            lblDatabase.setIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/icons/dbon.png"))));
            lblConexao.setForeground(new Color(0,255,0));
        } else {
            lblBanco.setText("Banco desconectado");
            lblDatabase.setIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/icons/dboff.png"))));
            lblConexao.setForeground(Color.RED);
        }
    }

//Obter a data - criação de metodo ------------------------------
    //Dica de segurança usar private se o metodo é exclusivo da classe
    private void atualizarData() {
        LocalDate hoje = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //.setText modifica o texto da label pela data formatada
        lblData.setText(hoje.format(formato));
    }

    //Abrir a tela SOBRE --------------------------
    private void sobre() {
        Sobre sobre = new Sobre(); // criar o objeto
        sobre.setVisible(true);//Abrir a janela SOBRE
    }

}
