package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;

public class Sobre extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JLabel lblGithub;


    public Sobre() {

        setSize(380,230); //tamanho da janela
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setTitle("Sobre");
        setResizable(false);
        setLocationRelativeTo(null);

        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);


        lblGithub.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        //evento do botão OK (pressionar botão)
        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK(); // //executa o metodo onOK()
            }
        });
        lblGithub.addComponentListener(new ComponentAdapter() {
        });

        lblGithub.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                acessarGithub("https://github.com/reginaldotfilho");
            }
        });
    }//FIM CONSTRUTOR

    private void onOK() {
        // dispose() fecha apenas está janela
        dispose();
    }

    //metodo para abrir um link no navegador padrão do desktop cliente
    private void acessarGithub(String url) {
        Desktop desktop = Desktop.getDesktop();
        try {
            URI uri = new URI(url);
            desktop.browse(uri);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
