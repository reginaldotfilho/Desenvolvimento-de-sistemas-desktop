package model;

public class Fornecedor {
    private int ifFornecedor;
    private String nome;
    private String fone;
    private String email;
    private String cnpj;

    public int getIfFornecedor() {
        return ifFornecedor;
    }

    public void setIfFornecedor(int ifFornecedor) {
        this.ifFornecedor = ifFornecedor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
}
