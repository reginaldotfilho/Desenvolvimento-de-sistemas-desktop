package controller;

//importação do modelo de dados (contato)

import dao.ContatoDAO;
import model.Contato;

import java.sql.SQLException;

public class ContatoController {
    //MVC - Controller faz as validações (regras de negócio)


    //instaciar o DAO
    //Final protege o objeto evitando a sua substituição no processo
    private final ContatoDAO contatoDAO = new ContatoDAO();

    //Crud create ====================
    public void adicionar(Contato contato) throws SQLException {
        validarContato(contato);
        //ele esta executando o DAO
        contatoDAO.adcionar(contato);
    }
    //FIm CRUD Create

    //Função para validar os dados do contato  (adicionar e editar) obs: (Ccntato  contato) é o objeto
    private void validarContato(Contato contato) {
        //getNome() == null (verifica se o nome doi preenchido)
        //.getNome().trim().isEmpty() - .trim() remove espaços em branco invisíveis no inio e fim (ex: "    " vira""
        if (contato.getNome() == null || contato.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o nome do contato.");
        }

        //remove espaços inuteis antes de salvar
        //Exemplo> se o usuario digitou " Joao Silva    ", ele limpa e ajusta para "Joao Silva")
        contato.setNome(contato.getNome().trim());

    }

}
