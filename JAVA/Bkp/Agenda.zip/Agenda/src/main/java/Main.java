//import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import view.Agenda;

public class Main {

// psvma (cria o método main
    static void main(String[] args) {
        //Uso do Flatlaf (tema visual moderno)
        //desatovazr avosps vernpsp: more actions(3 pontos) -> edit -> modify options -> add vm options
        //FlatDarkLaf.setup();
        FlatLightLaf.setup();

        Agenda janelaPrincipal = new Agenda();
        //Iniciando a janela principal
        janelaPrincipal.setVisible(true);

    }
}
