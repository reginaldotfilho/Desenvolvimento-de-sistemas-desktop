package dao;

import connection.ConnectionFactory;
import model.Contato;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ContatoDAO {
    //Este modulo trabala com JDBC (bibliotecas responsáveis pelo acesso ao banco de dados
    //DAO executa as instruções sql

    //CRUD create ========================================
    //Dica: usar o mesmo nome do controller
    public void adcionar(Contato contato) throws SQLException {
        //comando sql
        String sql = "insert into contato (nome, fone) values (?, ?)";

        //Instanciar o objeto fabrica (Connection Factory)
        ConnectionFactory fabrica = new ConnectionFactory();

        //Abrir a conexão com o banco de dados
        //Try (tratamento de exceção)
        //Connection JBDC (abrir a conexão com o banco)
        //PrepareStatement JBDC (preparar o comando  sql)

        try (Connection con = fabrica.conectar();
             PreparedStatement comando = con.prepareStatement(sql)) {
                //Substituir as (?, ?) pelo nome e fone do contato
                comando.setString(1, contato.getNome());
                comando.setString(2, contato.getFone());
                //Executar o comando
                comando.executeUpdate();

        }
    }
    //FIm Crud create ==========================================
}
