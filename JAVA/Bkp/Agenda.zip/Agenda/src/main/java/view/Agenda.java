package view;

import connection.ConnectionFactory;
import controller.ContatoController;
import model.Contato;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

//Criar a herança com JFrame
public class Agenda extends JFrame {
    //Código gerado UI Designer (componentes)
    private JPanel pnlMain;
    private JPanel pnlHeader;
    private JPanel pnlButton;
    private JPanel pnlBody;
    private JPanel pnlFooter;
    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtFone;
    private JButton btnBuscar;
    private JButton btnWhatsapp;
    private JButton btnAdicionar;
    private JButton btnEditar;
    private JButton btnExcluir;
    private JButton btnRelatorio;
    private JButton btnLimpar;
    private JLabel lblSobre;
    private JLabel lblDatabase;
    private JLabel lblBanco;
    private JLabel lblData;

    //CONTROLLER
    private final ContatoController contatoController = new ContatoController();

    //Construtor
    public Agenda() {
        //configuração da Janela

        //Tamanho em pixels
        setSize(600, 360);

        //comportamento da janela ao fechar (encerrar a aplicação)
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Titulo
        setTitle("Agenda");

        //icone de janela
        ImageIcon icone = new ImageIcon(getClass().getResource("/icons/favicon.png"));
        setIconImage(icone.getImage());

        //Impedir o redimensionamento
        setResizable(false);

        //iniciar em tela cheia
        // setExtendedState(JFrame.MAXIMIZED_BOTH);
        //quiosque (totem de auto-atendimento)
        //setUndecorated(true);
        //Iniciar a janela centralizada
        setLocationRelativeTo(null);

        //Incluir o formulário (UI Designer - painel principal)
        setContentPane(pnlMain);

        //Mãozinha
        btnWhatsapp.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        lblSobre.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        //"Chamar" o metodo para atualizar a data
        atualizarData();

        //Chamar o metodo para testar a conexao
        verificarConexao();

        //evento clicar no icone SOBRE para abrir a tela sobre (tela segundaria)
        lblSobre.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                //DIca para entendimento da logica e debug (teste do evento)
                //IO.println("teste do botão SOBRE")
                //executar o metodo SOBRE
                sobre();
            }

        });

        //Evento do botao adicionar
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //IO.println("teste do botão adicionar");
                adicionarContato();
            }

        });
        //Evento do botão limpar
        btnLimpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpar();

            }
        });
    }// fim do construtor

    //Limpar campos =======================================
    private void limpar() {
        txtId.setText(null);
        txtNome.setText(null);
        txtFone.setText(null); //sem mascara
        txtNome.requestFocusInWindow();// posiciona o cursor no nome
    }

    //testar a conexão com o banco de dados
    //criando um metodo verificarConexao
    private void verificarConexao() {
        //criar o objeto para acessar o metodo testaConexao()
        ConnectionFactory conexao = new ConnectionFactory();
        //se retorno for  verdadeiro concexão bem sucedida
        if (conexao.testarConexao() == true) {
            lblBanco.setText("Banco Conectado");
            lblDatabase.setIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/icons/dbon.png"))));
        } else {
            lblBanco.setText("Banco desconectado");
            lblDatabase.setIcon(new ImageIcon(Objects.requireNonNull(getClass().getResource("/icons/dboff.png"))));
        }
    }

    //Obter a data - criação de metodo ------------------------------

    //Dica de segurança usar private se o metodo é exclusivo da classe
    private void atualizarData() {
        LocalDate hoje = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        //.setText modifica o texto da label pela data formatada
        lblData.setText(hoje.format(formato));
    }

    //Abrir a tela SOBRE --------------------------
    private void sobre() {
        Sobre sobre = new Sobre(); // criar o objeto
        sobre.setVisible(true);//Abrir a janela SOBRE
    }

    //CRUD Create ===================================
    private void adicionarContato() {
        //Instanciar o contato (model)
        Contato contato = new Contato();
        //setar as variaveis do model com os dados do form
        contato.setNome(txtNome.getText());
        contato.setFone(txtFone.getText());
        //mensagens (validações)
        try {
            //validação e execução
            contatoController.adicionar(contato);
            //Caso OK
            JOptionPane.showMessageDialog(
            this,
            "Contato cadastrado com sucesso!",
            "Agenda de contatos",
            JOptionPane.INFORMATION_MESSAGE);
            //Limpar os campos
            limpar();
        } catch (IllegalArgumentException e) {
            //Erro de validação
            JOptionPane.showMessageDialog(
                    this, e.getMessage(),
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE
            );

        } catch (SQLException e) {
            //Exceção
            JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível cadastrar o contato.\n" + e.getMessage(),
                    "Erro no banco de dados",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    //Fim CRUD Create ==============================

}// Fim da classe Agenda
