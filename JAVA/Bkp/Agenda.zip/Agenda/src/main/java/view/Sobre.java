package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.net.URISyntaxException;

public class Sobre extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JPanel pnlBody;
    private JLabel lblGithub;

    public Sobre() {
        //Configuração da janela
        setSize(380,230); //tamanho da janela
        //Comportamento ao fechar
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        //Titulo
        setTitle("Sobre");
        //icone de janela
        ImageIcon icone = new ImageIcon(getClass().getResource("/icons/favicon.png"));
        setIconImage(icone.getImage());
        //Evitar redimensionamento
        setResizable(false);
        //Centralizar a janela
        setLocationRelativeTo(null);

        setContentPane(contentPane); //Painel principal
        setModal(true);//Impedir abertura de múltiplas instâncias da janela
        getRootPane().setDefaultButton(buttonOK); //associado ao ENTER com o click ambos fazem a mesma coisa.

        //Mãozinha
        lblGithub.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        //evento do botão OK (pressionar botão)
        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK(); // //executa o metodo onOK()
            }
        });
        lblGithub.addComponentListener(new ComponentAdapter() {
        });

        //Evento do link do GITHUB (abrir o repositorio quando clicar na tela SOBRE)
        lblGithub.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                acessarGithub("https://github.com/reginaldotfilho");
            }
        });
        lblGithub.addMouseListener(new MouseAdapter() {
        });
    }//fim do construtor

    //metodo para fechar a janela
    private void onOK() {

        // dispose() fecha apenas está janela
        dispose();
    }

    //metodo para abrir um link no navegador padrão do desktop do cliente
    private void acessarGithub (String url) {
        // a linha abaixo obtém o sistema operacional do cliente
        Desktop desktop = Desktop.getDesktop();
        try {
            //Criação de um objeto para acesssar os metodos necessários para
            // estabelecer uma conexão com a internet abrindo o link no navegador do cliente
            URI uri = new URI(url);
            desktop.browse(uri);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}//fim da classe SOBRE
