package model;

public class Contato {
    //MVC - Model é uma estrutura de dados relacionada as tabelas
    //encapsular variaveis realacionadas a tabela
    private int idContato;
    private String nome;
    private String fone;


    //Botao direito - generate getter and setter (selecionar tudo)

    public int getIdContato() {
        return idContato;
    }

    public void setIdContato(int idContato) {
        this.idContato = idContato;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
}
